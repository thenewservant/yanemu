DISCLAIMER:

This NES emulator is still in its Early alpha stage, thus bugs may appear.
Its timing is based off your screen's Vertical Synchronization,
so please set your refresh to 60Hz.

Usage:
in a powershell / mingw / Windows CMD terminal:

yanemu.exe <rom>

with <rom> a NES rom file in iNES 1.0 format (The most common format)

Controls

A      : F
B      : D
Select : S
Start  : Return (Enter)
D-pad  : Arrow keys
Reset  : R


(For the most curious)

List of the 10 most used instructions fed into the NES CPU (since boot) : i


------ Changelog (v0.1.1) ------

Improved PPUREAD timing behavior

------ Initial Release (v0.0.0) ------